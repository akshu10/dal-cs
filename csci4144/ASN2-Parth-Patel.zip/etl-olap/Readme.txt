
1. On timberlea my assignment is inside the following directory:
    {patel4}/csci4144/a2/etl-olap/ETL_OLAP.py
    where patel4 is my csid.


2. To execute this code you need to navigate the directory above and use the following command:
    python ETL_OLAP.py


